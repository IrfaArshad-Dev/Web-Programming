

document.addEventListener("DOMContentLoaded", function () {

    const products = [
        {
            name: "Wireless Headphones",
            price: 3500,
            category: "Electronics",
            brand: "Samsung",
            rating: 5,
            image: "images/products/headphones.jpg",
            description: "Enjoy high-quality sound with comfortable ear cushions and a stylish wireless design."
        },
        {
            name: "Smartphone",
            price: 25000,
            category: "Electronics",
            brand: "Apple",
            rating: 5,
            image: "images/products/smartphone.jpg",
            description: "A modern smartphone with useful features and excellent performance."
        },
        {
            name: "Luxury Wrist Watch",
            price: 4500,
            category: "Accessories",
            brand: "Generic",
            rating: 4,
            image: "images/products/watch.jpg",
            description: "A stylish wrist watch suitable for everyday use and special occasions."
        },
        {
            name: "Casual Sneakers",
            price: 6000,
            category: "Shoes",
            brand: "Nike",
            rating: 4,
            image: "images/products/sneakers.jpg",
            description: "Comfortable casual sneakers with a modern design."
        },
        {
            name: "Stylish Handbag",
            price: 5500,
            category: "Accessories",
            brand: "Generic",
            rating: 5,
            image: "images/products/handbag.jpg",
            description: "A beautiful handbag with a stylish and practical design."
        },
        {
            name: "Modern Laptop",
            price: 85000,
            category: "Electronics",
            brand: "Samsung",
            rating: 4,
            image: "images/products/laptop.jpg",
            description: "A modern laptop suitable for work, study and entertainment."
        },
        {
            name: "Men's Cotton T-Shirt",
            price: 1800,
            category: "Clothing",
            brand: "Nike",
            rating: 4,
            image: "images/products/tshirt.jpg",
            description: "Soft breathable cotton t-shirt for everyday comfort."
        },
        {
            name: "Denim Jacket",
            price: 4800,
            category: "Clothing",
            brand: "Generic",
            rating: 5,
            image: "images/products/jacket.jpg",
            description: "A classic denim jacket that goes with any outfit."
        },
        {
            name: "Formal Leather Shoes",
            price: 7500,
            category: "Shoes",
            brand: "Generic",
            rating: 3,
            image: "images/products/formalshoes.jpg",
            description: "Elegant leather shoes for office and formal events."
        },
        {
            name: "Air Fryer",
            price: 12000,
            category: "Home Appliances",
            brand: "Samsung",
            rating: 4,
            image: "images/products/airfryer.jpg",
            description: "Cook crispy food with little or no oil."
        },
        {
            name: "Electric Kettle",
            price: 3200,
            category: "Home Appliances",
            brand: "Generic",
            rating: 3,
            image: "images/products/kettle.jpg",
            description: "Fast-boiling 1.7L electric kettle with auto shut-off."
        }
    ];

    const PLACEHOLDER_IMG = "data:image/svg+xml;utf8," + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200">' +
        '<rect width="100%" height="100%" fill="#eeeef7"/>' +
        '<text x="50%" y="50%" fill="#8a8aa5" font-family="Arial" font-size="18" ' +
        'text-anchor="middle" dominant-baseline="middle">Image coming soon</text></svg>');

   
    document.addEventListener("error", function (e) {
        if (e.target.tagName === "IMG" && !e.target.dataset.fallback) {
            e.target.dataset.fallback = "1";
            e.target.src = PLACEHOLDER_IMG;
        }
    }, true);

    function formatPrice(price) {
        return "Rs. " + Number(price).toLocaleString("en-PK");
    }

    function getProductByName(name) {
        return products.find(function (product) {
            return product.name.toLowerCase() === name.toLowerCase();
        });
    }

    function getProductFromCard(card) {
        const name = card.querySelector("h3").textContent.trim();
        const savedProduct = getProductByName(name);

        if (!savedProduct) {
            return null;
        }

        return savedProduct;
    }




    const slides = document.querySelectorAll(".slide");
    const dots = document.querySelectorAll(".dot");
    const nextButton = document.querySelector(".next-btn");
    const prevButton = document.querySelector(".prev-btn");

    let currentSlide = 0;
    let slideTimer;

    function showSlide(index) {

        if (slides.length === 0) return;

        currentSlide = (index + slides.length) % slides.length;

        slides.forEach(function (slide, i) {
            slide.classList.toggle("active", i === currentSlide);
        });

        dots.forEach(function (dot, i) {
            dot.classList.toggle("active", i === currentSlide);
        });
    }

    function startSlideshow() {
        clearInterval(slideTimer);

        if (slides.length > 1) {
            slideTimer = setInterval(function () {
                showSlide(currentSlide + 1);
            }, 4000);
        }
    }

    if (slides.length > 0) {

        showSlide(0);
        startSlideshow();

        nextButton.addEventListener("click", function () {
            showSlide(currentSlide + 1);
            startSlideshow();
        });

        prevButton.addEventListener("click", function () {
            showSlide(currentSlide - 1);
            startSlideshow();
        });

        dots.forEach(function (dot, index) {
            dot.addEventListener("click", function () {
                showSlide(index);
                startSlideshow();
            });
        });
    }


 

    const menuButton = document.querySelector(".menu-btn");
    const closeDrawerButton = document.querySelector(".close-drawer");
    const drawer = document.querySelector(".navigation-drawer");
    const overlay = document.querySelector(".drawer-overlay");

    function openDrawer() {
        drawer.classList.add("active", "open");
        overlay.classList.add("active", "open");
        drawer.setAttribute("aria-hidden", "false");
    }

    function closeDrawer() {
        drawer.classList.remove("active", "open");
        overlay.classList.remove("active", "open");
        drawer.setAttribute("aria-hidden", "true");
    }

    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") closeDrawer();
    });

    menuButton.addEventListener("click", openDrawer);
    closeDrawerButton.addEventListener("click", closeDrawer);
    overlay.addEventListener("click", closeDrawer);

    drawer.querySelectorAll("a").forEach(function (link) {
        link.addEventListener("click", closeDrawer);
    });





    let cart = JSON.parse(localStorage.getItem("shopeaseCart")) || [];
    let wishlist = JSON.parse(localStorage.getItem("shopeaseWishlist")) || [];

    const cartItemsContainer = document.querySelector(".cart-items");
    const wishlistContainer = document.querySelector(".wishlist-container");

    cartItemsContainer.innerHTML = "";
    wishlistContainer.innerHTML = "";

    function saveCart() {
        localStorage.setItem("shopeaseCart", JSON.stringify(cart));
    }

    function saveWishlist() {
        localStorage.setItem("shopeaseWishlist", JSON.stringify(wishlist));
    }

    const headerCartLink = document.querySelector(
        '.header-icons a[href="#cart"]'
    );

    let headerCartCount = document.createElement("span");
    headerCartCount.className = "header-cart-count";

    if (headerCartLink) {
        headerCartLink.appendChild(headerCartCount);
    }
    function addToCart(product, quantity) {

        if (!product) return;

        quantity = Number(quantity) || 1;

        const existingProduct = cart.find(function (item) {
            return item.name === product.name;
        });

        if (existingProduct) {
            existingProduct.quantity += quantity;
        } else {
            cart.push({
                name: product.name,
                price: product.price,
                image: product.image,
                quantity: quantity
            });
        }

        saveCart();
        renderCart();

        alert(product.name + " added to your cart!");
    }


    function renderCart() {

        cartItemsContainer.innerHTML = "";

        cart.forEach(function (item, index) {

            const cartItem = document.createElement("div");
            cartItem.className = "cart-item";

            cartItem.innerHTML = `
                <img src="${item.image}" alt="${item.name}">

                <div class="cart-item-info">

                    <h3>${item.name}</h3>

                    <p>Price: ${formatPrice(item.price)}</p>

                    <div class="cart-quantity">

                        <button type="button" class="decrease-qty"
                            data-index="${index}">-</button>

                        <span class="cart-product-quantity">
                            ${item.quantity}
                        </span>

                        <button type="button" class="increase-qty"
                            data-index="${index}">+</button>

                    </div>

                    <button type="button" class="remove-btn"
                        data-index="${index}">
                        Remove
                    </button>

                </div>
            `;

            cartItemsContainer.appendChild(cartItem);
        });

        updateCartTotal();
    }

    cartItemsContainer.addEventListener("click", function (event) {

        const index = Number(event.target.dataset.index);

        if (event.target.classList.contains("increase-qty")) {

            cart[index].quantity++;
            saveCart();
            renderCart();
        }

        if (event.target.classList.contains("decrease-qty")) {

            if (cart[index].quantity > 1) {
                cart[index].quantity--;
            } else {
                cart.splice(index, 1);
            }

            saveCart();
            renderCart();
        }

        if (event.target.classList.contains("remove-btn")) {

            cart.splice(index, 1);
            saveCart();
            renderCart();
        }
    });

    function updateCartTotal() {

        let totalItems = 0;
        let subtotal = 0;

        cart.forEach(function (item) {
            totalItems += item.quantity;
            subtotal += item.price * item.quantity;
        });

        const delivery = subtotal > 0 ? 200 : 0;
        const total = subtotal + delivery;

        document.querySelector("#cart-count").textContent = totalItems;
        document.querySelector("#cart-subtotal").textContent =
            formatPrice(subtotal);

        document.querySelector("#delivery-charges").textContent =
            formatPrice(delivery);

        document.querySelector("#cart-total").textContent =
            formatPrice(total);

        headerCartCount.textContent = totalItems;
    }

    const mainGrid = document.querySelector("#main-products");
    const noResults = document.querySelector("#no-results");
    const resultsInfo = document.querySelector("#results-info");

    function stars(rating) {
        return "★".repeat(rating) + "☆".repeat(5 - rating) +
            " (" + rating + ".0)";
    }

    function createProductCard(product) {
        const card = document.createElement("div");
        card.className = "product-card";
        card.dataset.category = product.category;
        card.dataset.brand = product.brand;
        card.dataset.price = product.price;
        card.dataset.rating = product.rating;

        card.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p class="product-price">${formatPrice(product.price)}</p>
            <p class="product-rating">${stars(product.rating)}</p>
            <button type="button" class="add-cart-btn">Add to Cart</button>
            <a href="#product-details" class="details-btn">View Details</a>
            <button type="button" class="wishlist-btn">♡ Add to Wishlist</button>
        `;
        return card;
    }

    function renderMainProducts(list) {
        mainGrid.innerHTML = "";
        list.forEach(function (product) {
            mainGrid.appendChild(createProductCard(product));
        });

        noResults.hidden = list.length !== 0;
        mainGrid.hidden = list.length === 0;
        resultsInfo.textContent = list.length === 1
            ? "Showing 1 product"
            : "Showing " + list.length + " products";

        syncWishlistButtons();
    }

    const searchInput = document.querySelector("#search-input");
    const searchButton = document.querySelector("#search-btn");
    const minPriceInput = document.querySelector("#min-price");
    const maxPriceInput = document.querySelector("#max-price");

    function getFilteredProducts() {

        const term = searchInput.value.toLowerCase().trim();

        const categories = Array.from(
            document.querySelectorAll(".category-filter:checked")
        ).map(function (i) { return i.value; });

        const brands = Array.from(
            document.querySelectorAll(".brand-filter:checked")
        ).map(function (i) { return i.value; });

        const minPrice = Number(minPriceInput.value) || 0;
        const maxPrice = maxPriceInput.value === ""
            ? Infinity : Number(maxPriceInput.value);

        const ratingInput = document.querySelector(".rating-filter:checked");
        const minRating = ratingInput ? Number(ratingInput.value) : 0;

        return products.filter(function (p) {

            const searchMatch = term === "" ||
                p.name.toLowerCase().includes(term) ||
                p.category.toLowerCase().includes(term) ||
                p.brand.toLowerCase().includes(term) ||
                p.description.toLowerCase().includes(term);

            return searchMatch &&
                (categories.length === 0 || categories.includes(p.category)) &&
                (brands.length === 0 || brands.includes(p.brand)) &&
                p.price >= minPrice && p.price <= maxPrice &&
                p.rating >= minRating;
        });
    }

    function applyFilters() {
        renderMainProducts(getFilteredProducts());
    }

    function clearFilters(clearSearchToo) {
        document.querySelectorAll(
            ".category-filter, .brand-filter, .rating-filter"
        ).forEach(function (i) { i.checked = false; });

        minPriceInput.value = "";
        maxPriceInput.value = "";

        if (clearSearchToo) searchInput.value = "";
        applyFilters();
    }

    function goToProducts() {
        document.querySelector("#products").scrollIntoView({
            behavior: "smooth"
        });
    }
    function searchProducts() {
             clearFilters(false);
        goToProducts();
    }

    searchButton.addEventListener("click", searchProducts);

    searchInput.addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            event.preventDefault();
            searchProducts();
        }
    });

    searchInput.addEventListener("input", applyFilters);

    document.querySelectorAll(
        ".category-filter, .brand-filter, .rating-filter"
    ).forEach(function (input) {
        input.addEventListener("change", applyFilters);
    });

    minPriceInput.addEventListener("input", applyFilters);
    maxPriceInput.addEventListener("input", applyFilters);

    document.querySelector("#clear-filters-btn")
        .addEventListener("click", function () { clearFilters(true); });

    document.querySelector("#no-results-clear")
        .addEventListener("click", function () { clearFilters(true); });

    document.querySelectorAll(".category-card").forEach(function (card) {

        card.addEventListener("click", function () {

            const categoryName = card.querySelector("h3").textContent.trim();

            clearFilters(true);

            document.querySelectorAll(".category-filter").forEach(
                function (checkbox) {
                    checkbox.checked = checkbox.value === categoryName;
                }
            );

            applyFilters();
            goToProducts();
        });
    });

    let currentDetailsProduct = products[0];

    const detailsSection = document.querySelector(".product-details-section");

    function showProductDetails(product) {

        if (!product) return;

        currentDetailsProduct = product;

        const img = detailsSection.querySelector(".product-details-image img");
        delete img.dataset.fallback;
        img.src = product.image;
        img.alt = product.name;

        detailsSection.querySelector(".product-details-info h2")
            .textContent = product.name;

        detailsSection.querySelector(".product-details-info h3")
            .textContent = formatPrice(product.price);

        detailsSection.querySelector(".product-rating").textContent =
            stars(product.rating).replace("(", "(").replace(")", " Rating)");

        detailsSection.querySelector(".product-description")
            .textContent = product.description;

        document.querySelector("#product-quantity").value = 1;

        detailsSection.scrollIntoView({ behavior: "smooth" });
    }


    
    function inWishlist(name) {
        return wishlist.some(function (item) { return item.name === name; });
    }

    function syncWishlistButtons() {
        document.querySelectorAll(".wishlist-btn").forEach(function (btn) {
            const card = btn.closest(".product-card");
            if (!card) return;
            const added = inWishlist(card.querySelector("h3").textContent.trim());
            btn.textContent = added ? "♥ Remove from Wishlist" : "♡ Add to Wishlist";
            btn.classList.toggle("in-wishlist", added);
        });
    }

    function toggleWishlist(product) {

        if (!product) return;

        if (inWishlist(product.name)) {
            wishlist = wishlist.filter(function (item) {
                return item.name !== product.name;
            });
        } else {
            wishlist.push(product);
        }

        saveWishlist();
        renderWishlist();
    }

    function renderWishlist() {

        wishlistContainer.innerHTML = "";

        if (wishlist.length === 0) {
            wishlistContainer.innerHTML = "<p>Your wishlist is empty.</p>";
        }

        wishlist.forEach(function (product, index) {

            const item = document.createElement("div");
            item.className = "wishlist-item";

            item.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <div class="wishlist-info">
                    <h3>${product.name}</h3>
                    <p>${formatPrice(product.price)}</p>
                    <button type="button" class="add-wishlist-cart"
                        data-index="${index}">Add to Cart</button>
                    <button type="button" class="remove-wishlist-btn"
                        data-index="${index}">Remove from Wishlist</button>
                </div>
            `;

            wishlistContainer.appendChild(item);
        });

        syncWishlistButtons();
    }

    wishlistContainer.addEventListener("click", function (event) {

        const index = Number(event.target.dataset.index);

        if (event.target.classList.contains("remove-wishlist-btn")) {
            wishlist.splice(index, 1);
            saveWishlist();
            renderWishlist();
        }

        if (event.target.classList.contains("add-wishlist-cart")) {
            addToCart(getProductByName(wishlist[index].name), 1);
        }
    });

    document.addEventListener("click", function (event) {

        const addBtn = event.target.closest(".add-cart-btn");
        const detailsBtn = event.target.closest(".details-btn");
        const wishBtn = event.target.closest(".wishlist-btn");

        if (addBtn) {
            const card = addBtn.closest(".product-card");

            if (card) {
                addToCart(getProductFromCard(card), 1);
            } else {
                const qty = Number(
                    document.querySelector("#product-quantity").value
                );
                addToCart(currentDetailsProduct, qty >= 1 ? qty : 1);
            }
        }

        if (detailsBtn) {
            event.preventDefault();
            const card = detailsBtn.closest(".product-card");
            if (card) showProductDetails(getProductFromCard(card));
        }

        if (wishBtn) {
            const card = wishBtn.closest(".product-card");
            if (card) toggleWishlist(getProductFromCard(card));
        }
    });


 

    document.querySelector("#login-form").addEventListener(
        "submit", function (event) {

            event.preventDefault();

            const email = document.querySelector("#login-email").value;
            const password = document.querySelector("#login-password").value;

            if (password.length < 6) {
                alert("Password must contain at least 6 characters.");
                return;
            }

            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                alert("Please enter a valid email address.");
                return;
            }

            localStorage.setItem("shopeaseUser", email);
            updateUserUI();
            alert("Login successful! Welcome " + email);
            this.reset();
        }
    );



    document.querySelector("#signup-form").addEventListener(
        "submit", function (event) {

            event.preventDefault();

            const name = document.querySelector("#signup-name").value;
            const email = document.querySelector("#signup-email").value;
            const phone = document.querySelector("#signup-phone").value;
            const password = document.querySelector("#signup-password").value;
            const confirmPassword = document.querySelector("#confirm-password").value;

            if (name.trim().length < 3) {
                alert("Please enter a valid name.");
                return;
            }

            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                alert("Please enter a valid email address.");
                return;
            }

            if (!/^[0-9+\-\s]{10,15}$/.test(phone)) {
                alert("Please enter a valid phone number.");
                return;
            }

            if (password.length < 6) {
                alert("Password must contain at least 6 characters.");
                return;
            }

            if (password !== confirmPassword) {
                alert("Passwords do not match!");
                return;
            }

            alert("Account created successfully! (Demo only)");
            this.reset();
        }
    );


    document.querySelector("#contact-form").addEventListener(
        "submit", function (event) {

            event.preventDefault();

            alert("Thank you! Your message has been submitted.");
            this.reset();
        }
    );


  

    document.querySelector("#forgot-password-form").addEventListener(
        "submit", function (event) {

            event.preventDefault();

            const email = document.querySelector("#forgot-email").value;

            alert("Password reset instructions would be sent to " + email +
                " (Demo only).");

            this.reset();
        }
    );



    document.querySelector(".checkout-btn").addEventListener(
        "click", function () {

            if (cart.length === 0) {
                alert("Your cart is empty!");
                return;
            }

            const orderNo = 1000 + document.querySelectorAll(".order-card").length + 1;
            const itemsText = cart.map(function (i) {
                return i.name + " x" + i.quantity;
            }).join(", ");
            const orderTotal = document.querySelector("#cart-total").textContent;

            const order = document.createElement("div");
            order.className = "order-card";
            order.innerHTML = "<strong>Order #" + orderNo + "</strong> - " + itemsText +
                "<br>Total: " + orderTotal +
                ' | <span class="order-status">Processing</span>';
            document.querySelector("#orders-list").prepend(order);

            cart = [];
            saveCart();
            renderCart();
            alert("Order placed successfully! See it in My Orders.");
        }
    );


    const drawerUser = document.querySelector("#drawer-user");
    const profileBox = document.querySelector("#profile .form-container");

    function updateUserUI() {
        const user = localStorage.getItem("shopeaseUser");

        drawerUser.textContent = user ? "Welcome, " + user : "Welcome, Guest";

        profileBox.innerHTML = user
            ? '<ul class="account-list">' +
              "<li><strong>Name:</strong> " + user.split("@")[0] + "</li>" +
              "<li><strong>Email:</strong> " + user + "</li>" +
              "<li><strong>Phone:</strong> +92 300 1234567</li>" +
              "<li><strong>City:</strong> Rawalpindi, Pakistan</li></ul>"
            : "<p>Please log in to view and manage your personal account information.</p>" +
              '<a href="#login">Login to your account</a>';
    }

    document.querySelector("#logout-btn").addEventListener("click", function () {
        if (localStorage.getItem("shopeaseUser")) {
            localStorage.removeItem("shopeaseUser");
            updateUserUI();
            alert("You have been logged out.");
        }
    });


    renderCart();
    renderWishlist();
    applyFilters();
    updateUserUI();

});
